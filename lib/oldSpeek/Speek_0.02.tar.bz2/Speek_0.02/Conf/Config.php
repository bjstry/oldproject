<?php
return array(
	'DT_MODEL'         =>'Home',
	'DT_URLTYPE'         =>3,
	'DT_CONTROLLER'    =>'Index',
	'DT_ACTION'        =>'Index',
	'DT_THEME'         =>'default',
	'DT_CHARSET'       =>'utf-8',
);
?>
